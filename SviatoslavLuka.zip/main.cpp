#include <iostream>
#include <boost/filesystem/operations.hpp>
#include <vector>

namespace fs1 = boost::filesystem;

void Help(){
    std::cout<<"mymkdir [-h|--help] [-p]  <dirname>\n"<<std::endl;
}

std::string get_current_directory(){
    char buf[200];
    getcwd(buf, sizeof(buf));
    return std::string(buf);
}

void make_dir(fs1::path Dir, bool keyP){
    fs1::path directory1;
    if(Dir.parent_path().empty()){
        directory1 = get_current_directory() + "/" + Dir.filename().string();
    }
    else{
        directory1 = Dir;
    }
    if(fs1::is_directory(directory1)){
        if(not keyP){
            std::cout<<"Error : This directory exists!!! ("<<directory1<<")"<<std::endl;
            exit(1);
        }
    }
    else{
        if(keyP){
            fs1::create_directories(directory1);
        }
        else if(fs1::is_directory(directory1.parent_path())){
            fs1::create_directory(directory1);
        }
        /////////////

    }
}

int main(int argc, char *argv[]) {
    bool keyP = false;
    bool helpKey = false;
    std::vector<std::string> DataFromConsol;
    for(int i = 1; i < argc; ++i){
        //DataFromConsol1.emplace_back(argv[i]);
        if(strcmp(argv[i], "-p") == 0 ){
            keyP = true;
        }
        else if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
            helpKey = true;
        }
        else{
            DataFromConsol.emplace_back(argv[i]);
        }
    }



    if(helpKey){
        Help();
        exit(0);
    }

    for(int i = 0; i < DataFromConsol.size(); ++i){
        fs1::path directory1 = DataFromConsol[i];
        make_dir(directory1,keyP);
    }
    return 0;
}